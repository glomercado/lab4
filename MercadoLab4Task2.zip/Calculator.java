/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package calculator;

/**
 *
 * @author gloadelyn.mercado916
 */
public class Calculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        CalcView theView = new CalcView();
        CalcModel theModel = new CalcModel();
        CalcController theController = new CalcController(theView, theModel);
        
        //theView.setVisible(true);
        
        
        // TODO code application logic here
    }
    
}
