/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab4;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author gloadelyn.mercado916
 */
public class ChatScreenModel {
    
    private String output;
    
    public void reverseText(String input)
    {
        output = "";
        for(int i = input.length()-1; i>=0; i-- )
        {
            this.output += input.charAt(i);
        }
    }

    public String getReverseText()
    {
        return this.output;
    }
}
