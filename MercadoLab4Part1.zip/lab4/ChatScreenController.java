/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author gloadelyn.mercado916
 */
public class ChatScreenController {
    
    private ChatScreenModel model;
    private ChatScreenView view;
    
    public ChatScreenController(ChatScreenView view, ChatScreenModel model)
    {
        this.model = model;
        this.view = view;
        
        this.view.addChatScreenListener(new ChatScreenListener());
        
    }
    
    class ChatScreenListener implements ActionListener
    {
        String input, output;
        
        public void actionPerformed(ActionEvent e)
        {
            try{
                input = view.getText(); 
                model.reverseText(input);
                output = model.getReverseText();
                view.displayText(output);
            }
            catch(Exception ex)
            {
                System.out.println(ex);
            }
        }
    }
    
}
