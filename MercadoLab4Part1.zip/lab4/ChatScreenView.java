/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 *
 * @author gloadelyn.mercado916
 */
public class ChatScreenView extends JFrame{
    
        private final JButton sendButton;
	private final JButton exitButton;
	private final JTextField sendText;
	private final JTextArea displayArea;
        private final JFrame frame;
        
        
        ChatScreenView() {
            frame = new JFrame("Demo");
        
        
        /** anonymous inner class to handle window closing events */
	frame.addWindowListener(new WindowAdapter() {
                @Override
		public void windowClosing(WindowEvent evt) {
				System.exit(0);
			}
		} );

		/**
		 * a panel used for placing components
		 */
		JPanel p = new JPanel();

	Border etched = BorderFactory.createEtchedBorder();
        Border titled = BorderFactory.createTitledBorder(etched, "Enter Your Message Here ...");
        p.setBorder(titled);

		/**
		 * set up all the components
		 */
		sendText = new JTextField(30);
		sendButton = new JButton("Send");
		exitButton = new JButton("Exit");

		/**
		 * register the listeners for the different button clicks
		 */
                
                
		/**
		 * add the components to the panel
		 */
		p.add(sendText);
		p.add(sendButton);
		p.add(exitButton);

		/**
		 * add the panel to the "south" end of the container
		 */
		frame.getContentPane().add(p,"South");

		/**
		 * add the text area for displaying output. Associate
		 * a scrollbar with this text area. Note we add the scrollpane
		 * to the container, not the text area
		 */
		displayArea = new JTextArea(15,40);
		displayArea.setEditable(false);
		displayArea.setFont(new Font("SansSerif", Font.PLAIN, 16));

		JScrollPane scrollPane = new JScrollPane(displayArea);
		frame.getContentPane().add(scrollPane,"Center");

		/**
		 * set the title and size of the frame
		 */
		frame.pack();
        
                
                
            frame.setVisible(true);
            sendText.requestFocus();
	}

        public String getText()
        {
            String text = sendText.getText().trim();
            sendText.setText("");
            return text;
        }
        
        public void displayText(String reversed)
        {
            
            displayArea.append(reversed + "\n");
        }
        
        void addChatScreenListener(ActionListener listenForButton)
        {
            sendButton.addActionListener(listenForButton);
        }
        
        void displayErrorMessage(String errMsg)
        {
            JOptionPane.showMessageDialog(this, errMsg);
        }
        
    
}
